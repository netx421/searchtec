# SPDX-License-Identifier: AGPL-3.0-or-later
# lint: pylint
""".. _tools src:

A collection of *utilities* used by SearXNG, but without SearXNG specific
peculiarities.

"""
