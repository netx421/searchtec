=======================
Developer documentation
=======================

.. toctree::
   :maxdepth: 2

   quickstart
   contribution_guide
   engines/index
   search_api
   plugins
   translation
   lxcdev
   makefile
   reST
   searxng_extra/index
