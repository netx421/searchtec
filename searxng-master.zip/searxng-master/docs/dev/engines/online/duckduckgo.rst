.. _duckduckgo engines:

=================
DukcDukGo Engines
=================

.. contents::
   :depth: 2
   :local:
   :backlinks: entry

.. automodule:: searx.engines.duckduckgo
   :members:

.. automodule:: searx.engines.duckduckgo_images
   :members:

.. automodule:: searx.engines.duckduckgo_definitions
   :members:

.. automodule:: searx.engines.duckduckgo_weather
   :members:
