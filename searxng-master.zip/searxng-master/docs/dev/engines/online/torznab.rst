.. _torznab engine:

==============
Torznab WebAPI
==============

.. contents::
   :depth: 2
   :local:
   :backlinks: entry

.. automodule:: searx.engines.torznab
   :members:
