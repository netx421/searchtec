.. _tagesschau engine:

==============
Tagesschau API
==============

.. contents:: Contents
   :depth: 2
   :local:
   :backlinks: entry

.. automodule:: searx.engines.tagesschau
  :members:
