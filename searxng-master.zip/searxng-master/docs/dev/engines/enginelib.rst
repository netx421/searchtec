.. _searx.enginelib:

==============
Engine Library
==============

.. contents::
   :depth: 2
   :local:
   :backlinks: entry

.. automodule:: searx.enginelib
  :members:

.. _searx.enginelib.traits:


Engine traits
=============

.. automodule:: searx.enginelib.traits
  :members:
