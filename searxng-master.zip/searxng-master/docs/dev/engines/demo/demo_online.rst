.. _demo online engine:

==================
Demo Online Engine
==================

.. contents::
   :depth: 2
   :local:
   :backlinks: entry

.. automodule:: searx.engines.demo_online
  :members:

