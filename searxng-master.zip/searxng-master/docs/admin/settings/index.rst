========
Settings
========

.. sidebar:: Further reading ..

   - :ref:`engine settings`
   - :ref:`engine file`

.. toctree::
   :maxdepth: 2

   settings
   settings_engine
   settings_brand
   settings_general
   settings_search
   settings_server
   settings_ui
   settings_redis
   settings_outgoing
   settings_categories_as_tabs



