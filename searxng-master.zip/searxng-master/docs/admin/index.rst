===========================
Administrator documentation
===========================

.. toctree::
   :maxdepth: 2

   settings/index
   installation
   installation-docker
   installation-scripts
   installation-searxng
   installation-uwsgi
   installation-nginx
   installation-apache
   update-searxng
   answer-captcha
   api
   architecture
   plugins
   buildhosts
